let screen = "start";
let truck;
let crops = [];
let obstacles = [];
let delivered = false;
let deliveredSoundPlayed = false;

// Fumaça
let smokeParticles = [];

// Confetes
let confetti = [];
let confettiColors = ['#E74C3C', '#3498DB', '#F1C40F', '#2ECC71', '#9B59B6'];

// Som aplausos
let applause;

// Tela start - animação
let startAnimFrame = 0;
let sunY;
let plantOffsets = [];

function setup() {
  createCanvas(800, 400);

  // Inicializa caminhão
  truck = { x: 0, y: 330, speed: 3, carrying: false };

  // Inicializa aplausos
  applause = new p5.Oscillator('triangle');
  applause.start();
  applause.amp(0);

  // Inicializa confetes
  for (let i = 0; i < 100; i++) {
    confetti.push(new Confetti());
  }

  // Início do sol e plantas para tela start
  sunY = height;
  for (let i = 0; i < 5; i++) {
    plantOffsets.push(random(TWO_PI));
  }
}

function draw() {
  if (screen === "start") {
    drawStartScene();
  } else if (screen === "farm") {
    drawFarmScene();
  } else if (screen === "drive") {
    drawDriveScene();
  } else if (screen === "city") {
    drawCityScene();
  } else if (screen === "end") {
    drawEndScene();
  }
}

// --- TELA INICIAL COM ANIMAÇÃO ---
function drawStartScene() {
  // Céu com gradiente noturno para dia amanhecendo
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let c = lerpColor(color(15, 30, 70), color(100, 170, 255), inter);
    stroke(c);
    line(0, y, width, y);
  }

  // Sol nascendo com brilho suave
  sunY = lerp(sunY, height * 0.3, 0.02);
  noStroke();
  let sunX = width / 2;
  for (let r = 70; r > 0; r -= 10) {
    fill(255, 204, 0, map(r, 70, 0, 20, 150));
    ellipse(sunX, sunY, r * 2);
  }
  fill(255, 204, 0);
  ellipse(sunX, sunY, 80);

  // Plantinhas animadas balançando na base
  for (let i = 0; i < 5; i++) {
    let x = 100 + i * 140;
    let baseY = height * 0.75;
    let sway = sin(startAnimFrame * 0.05 + plantOffsets[i]) * 10;

    // Caule
    stroke(34, 139, 34);
    strokeWeight(5);
    line(x, baseY, x + sway, baseY - 50);

    // Folhas
    noStroke();
    fill(34, 139, 34);
    ellipse(x + sway + 5, baseY - 40, 20, 40);
    ellipse(x + sway - 10, baseY - 50, 15, 25);

    // Espiga pequena animada
    fill(255, 223, 0);
    ellipse(x + sway, baseY - 70 + sin(startAnimFrame * 0.1 + i) * 5, 20, 40);
  }

  startAnimFrame++;

  // Texto animado com sombra leve e cores
  textAlign(CENTER, CENTER);
  textSize(42);
  stroke(255, 204, 0);
  strokeWeight(6);
  fill(34, 139, 34);
  text("🌽 Agrinho 2025: A Jornada do Milho 🌽", width / 2, height / 4);

  noStroke();
  fill(255);
  textSize(22);
  text("Plante, colha e leve seu milho até a cidade!", width / 2, height / 2);
  textSize(18);
  text("Clique para começar", width / 2, height * 0.75 + 40);
}

function mousePressed() {
  if (screen === "start") {
    screen = "farm";
    setupCrops();
  }
}

// --- FAZENDA ---
function setupCrops() {
  crops = [];
  for (let i = 0; i < 5; i++) {
    crops.push({ x: 100 + i * 110, y: 300, state: "empty", timer: 0 });
  }
  truck.x = 0;
  truck.y = 330;
  truck.carrying = false;
  deliveredSoundPlayed = false;
  obstacles = [];
}

function drawFarmScene() {
  // Céu azul claro com leves nuvens
  background(135, 206, 235);
  drawMovingClouds();

  // Solo com textura suave
  fill(80, 140, 30);
  noStroke();
  rect(0, 320, width, 80);

  // Textura do chão com linhas leves
  stroke(60, 110, 20, 80);
  strokeWeight(2);
  for (let i = 0; i < width; i += 15) {
    line(i, 350, i + 20, 370);
  }
  noStroke();

  // Desenha plantas com mais detalhes e folhas animadas
  for (let c of crops) {
    drawCornPlant(c);
  }

  fill(0);
  textSize(16);
  textAlign(LEFT);
  text("P: plantar milho | C: colher e iniciar entrega", 10, 20);

  drawTruck();
}

function drawCornPlant(c) {
  push();
  translate(c.x, c.y);

  // Folhas balançando se crescendo
  let sway = 0;
  if (c.state === "growing") sway = sin(c.timer * 0.1) * 5;

  // Caule verde
  fill(34, 139, 34);
  rect(15 + sway, 0, 10, 40);

  if (c.state === "empty") {
    fill(139, 69, 19);
    rect(0, 20, 40, 20);
  } else {
    // Espiga amarela com brilho
    fill(255, 223, 0);
    ellipse(20 + sway, -10 + c.timer * 0.1, 25, 50);

    // Brilho da espiga (pequenos círculos amarelos)
    fill(255, 255, 100, 150);
    ellipse(20 + sway - 5, -15, 6);
    ellipse(20 + sway + 5, -5, 6);
  }

  pop();

  if (c.state === "growing") {
    c.timer++;
    if (c.timer > 200) c.state = "ready";
  }
}

// --- ESTRADA ---
function drawDriveScene() {
  // Céu com gradiente azul vibrante
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let c = lerpColor(color(135, 206, 235), color(70, 130, 180), inter);
    stroke(c);
    line(0, y, width, y);
  }

  // Montanhas com textura
  drawMountains();

  // Árvores com folhas que balançam
  drawAnimatedTrees();

  // Estrada com faixa central amarela
  fill(80);
  rect(0, 350, width, 50);
  drawRoadStripes();

  // Obstáculos
  if (obstacles.length === 0) generateObstacles();

  for (let obs of obstacles) {
    obs.x += obs.speed;
    if (obs.x < 0 || obs.x > width - obs.w) obs.speed *= -1;
    drawTrash(obs.x, obs.y);
  }

  // Movimento do caminhão
  if (keyIsDown(65)) truck.x -= truck.speed; // A
  if (keyIsDown(68)) truck.x += truck.speed; // D
  if (keyIsDown(87)) truck.y -= truck.speed; // W
  if (keyIsDown(83)) truck.y += truck.speed; // S

  truck.x = constrain(truck.x, 0, width - 90);
  truck.y = constrain(truck.y, 300, 350);

  // Colisão simples com obstáculos
  for (let obs of obstacles) {
    if (
      truck.x + 60 > obs.x &&
      truck.x < obs.x + obs.w &&
      truck.y + 30 > obs.y &&
      truck.y < obs.y + obs.h
    ) {
      screen = "end";
      delivered = false;
    }
  }

  drawTruck();

  // Se o caminhão ultrapassar 80% da largura, vai direto para a cidade
  if (truck.x > width * 0.8) {
    screen = "city";
    delivered = true;
  }
}

function drawMountains() {
  noStroke();
  fill(100, 155, 100);
  triangle(100, 250, 200, 100, 300, 250);
  triangle(250, 250, 350, 120, 450, 250);
  triangle(400, 250, 550, 130, 700, 250);

  // Textura simples de pedra com círculos leves
  fill(90, 140, 90, 100);
  ellipse(200, 200, 60, 40);
  ellipse(300, 180, 40, 30);
  ellipse(350, 210, 50, 35);
  ellipse(450, 170, 30, 20);
}

let treeSwayFrame = 0;
function drawAnimatedTrees() {
  for (let x = 50; x < width; x += 150) {
    let sway = sin(treeSwayFrame * 0.05 + x * 0.1) * 5;

    // Tronco
    fill(101, 67, 33);
    rect(x + sway, 280, 15, 40, 5);

    // Copa folhas
    fill(34, 139, 34);
    ellipse(x + 7 + sway, 270, 50, 50);
    ellipse(x + 25 + sway, 260, 40, 40);
  }
  treeSwayFrame++;
}

function drawRoadStripes() {
  stroke(255, 255, 0);
  strokeWeight(6);
  for (let i = 0; i < width; i += 40) {
    line(i, 375, i + 20, 375);
  }
  noStroke();
}

// --- CIDADE ---
function drawCityScene() {
  // Céu azul claro com nuvens animadas
  background(220, 240, 255);
  drawMovingClouds();

  // Prédios coloridos com janelas brilhantes
  drawCityBuildings();

  // Rua da cidade
  fill(100);
  rect(0, 320, width, 80);

  stroke(255, 255, 0);
  strokeWeight(5);
  for (let i = 0; i < width; i += 40) {
    line(i, 360, i + 20, 360);
  }
  noStroke();

  drawTruck();

  // Mensagem e confetes
  fill(0);
  textAlign(CENTER, CENTER);
  textSize(20);
  text("🎉 Parabéns! Chegou a hora de festejar a nossa plantação chegou até a cidade! 🚜🌽🏙️", width / 2, height / 3);

  // Confetes animados
  for (let c of confetti) {
    c.update();
    c.draw();
  }

  // Toca som uma vez só
  if (!deliveredSoundPlayed) {
    playApplause();
    deliveredSoundPlayed = true;
  }
}

function drawCityBuildings() {
  let baseX = 100;
  let heights = [150, 170, 120, 140, 160, 130];
  let colors = [
    '#b85c38', '#c68b59', '#7e6748', '#a5754a', '#dcae82', '#b88e55'
  ];

  for (let i = 0; i < 6; i++) {
    fill(colors[i]);
    rect(baseX + i * 80, height - heights[i] - 80, 60, heights[i], 10);

    // Janelas com brilho animado
    let windowColor = color(255, 255, 150, 150 + 100 * sin(frameCount * 0.05 + i));
    fill(windowColor);
    for (let j = 0; j < 5; j++) {
      rect(baseX + i * 80 + 10, height - heights[i] - 70 + j * 30, 15, 20, 3);
    }
  }
}

// --- CENAS FINAIS E ERRO ---
function drawEndScene() {
  background(200, 250, 200);

  // Desenha confetes
  for (let c of confetti) {
    c.update();
    c.draw();
  }

  textAlign(CENTER, CENTER);
  textSize(28);
  fill(0);

  if (delivered) {
    text("🎉 Parabéns! Sua plantação chegou até a cidade! 🚜🌽🏙️", width / 2, height / 2);

    if (!deliveredSoundPlayed) {
      playApplause();
      deliveredSoundPlayed = true;
    }
  } else {
    text("❌ Caminhão bateu! Tente novamente.", width / 2, height / 2);
  }
}

// --- CAMINHÃO COM FUMAÇA ---
function drawTruck() {
  // Carroceria rosa
  fill(255, 105, 180);
  rect(truck.x, truck.y, 60, 25, 4);

  // Carga (milho amarelo)
  if (truck.carrying) {
    fill(255, 223, 0);
    rect(truck.x + 5, truck.y - 10, 50, 10, 3);
  }

  // Cabine azul clara
  fill(135, 206, 250);
  rect(truck.x + 60, truck.y - 10, 30, 35, 5);

  // Para-brisa
  fill(200, 240, 255);
  rect(truck.x + 65, truck.y - 5, 15, 15, 3);

  // Para-choque
  fill(100);
  rect(truck.x + 88, truck.y + 8, 8, 10);

  // Detalhes
  stroke(0);
  strokeWeight(1);
  line(truck.x + 60, truck.y - 10, truck.x + 60, truck.y + 25);
  noStroke();

  // Farol
  fill(255, 255, 100);
  ellipse(truck.x + 90, truck.y + 8, 6, 6);

  // Rodas traseiras
  fill(30);
  ellipse(truck.x + 15, truck.y + 30, 22);
  fill(120);
  ellipse(truck.x + 15, truck.y + 30, 10);

  // Rodas dianteiras
  fill(30);
  ellipse(truck.x + 70, truck.y + 30, 18);
  fill(120);
  ellipse(truck.x + 70, truck.y + 30, 8);

  // Escapamento
  fill(40);
  rect(truck.x + 55, truck.y + 5, 8, 6, 2);

  // Fumaça
  let smokeX = truck.x + 60;
  let smokeY = truck.y + 5;

  if (frameCount % 3 === 0) {
    smokeParticles.push(new SmokeParticle(smokeX, smokeY));
  }

  for (let i = smokeParticles.length - 1; i >= 0; i--) {
    let p = smokeParticles[i];
    p.update();
    p.draw();

    if (p.isDead()) {
      smokeParticles.splice(i, 1);
    }
  }
}

class SmokeParticle {
  constructor(x, y) {
    this.x = x + random(-5, 5);
    this.y = y;
    this.size = random(10, 20);
    this.alpha = 255;
    this.speedY = random(0.5, 1.5);
    this.speedX = random(-0.3, 0.3);
  }
  update() {
    this.y -= this.speedY;
    this.x += this.speedX;
    this.alpha -= 3;
    this.size += 0.1;
  }
  draw() {
    noStroke();
    fill(120, this.alpha);
    ellipse(this.x, this.y, this.size);
  }
  isDead() {
    return this.alpha <= 0;
  }
}

function generateObstacles() {
  obstacles = [];
  for (let i = 0; i < 6; i++) {
    obstacles.push({
      x: random(200, width - 200),
      y: 320,
      w: 30,
      h: 30,
      speed: random(1, 2) * (random() < 0.5 ? 1 : -1), // velocidade e direção aleatória
    });
  }
}

function drawTrash(x, y) {
  fill(80);
  rect(x, y, 30, 30, 5);

  fill(50);
  rect(x + 5, y - 5, 20, 10, 3);
}

// --- CONFETES ---
class Confetti {
  constructor() {
    this.x = random(width);
    this.y = random(-50, 0);
    this.size = random(8, 15);
    this.color = random(confettiColors);
    this.speedY = random(2, 5);
    this.angle = random(TWO_PI);
    this.spinSpeed = random(0.05, 0.1);
  }
  update() {
    this.y += this.speedY;
    this.angle += this.spinSpeed;
    if (this.y > height) {
      this.y = random(-50, 0);
      this.x = random(width);
    }
  }
  draw() {
    push();
    translate(this.x, this.y);
    rotate(this.angle);
    noStroke();
    fill(this.color);
    rect(0, 0, this.size, this.size / 3, 2);
    pop();
  }
}

function playApplause() {
  applause.freq(300);
  applause.amp(0.5, 0.05);
  setTimeout(() => applause.amp(0, 0.5), 1000);
}

function keyPressed() {
  if (screen === "farm") {
    if (key === "P" || key === "p") {
      for (let c of crops) {
        if (c.state === "empty") {
          c.state = "growing";
          c.timer = 0;
          break;
        }
      }
    } else if (key === "C" || key === "c") {
      for (let c of crops) {
        if (c.state === "ready") {
          c.state = "empty";
          truck.carrying = true;
          screen = "drive";
          generateObstacles();
          break;
        }
      }
    }
  }
  if (screen === "end") {
    if (key === "R" || key === "r") {
      screen = "start";
      truck.carrying = false;
      deliveredSoundPlayed = false;
      sunY = height;  // reseta sol para tela inicial
      startAnimFrame = 0;
    }
  }
}

// --- NUVENS ANIMADAS (utilizadas no campo e na cidade) ---
let cloudPositions = [];
function drawMovingClouds() {
  if (cloudPositions.length === 0) {
    for (let i = 0; i < 5; i++) {
      cloudPositions.push({ x: random(width), y: random(30, 100), speed: random(0.3, 0.7) });
    }
  }
  noStroke();
  fill(255, 255, 255, 200);
  for (let cloud of cloudPositions) {
    ellipse(cloud.x, cloud.y, 60, 40);
    ellipse(cloud.x + 30, cloud.y + 10, 50, 35);
    ellipse(cloud.x - 25, cloud.y + 10, 45, 30);

    cloud.x += cloud.speed;
    if (cloud.x - 100 > width) cloud.x = -100;
  }
}
